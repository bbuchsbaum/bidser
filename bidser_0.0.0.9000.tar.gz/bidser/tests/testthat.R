library(testthat)
library(bidser)

test_check("bidser")
